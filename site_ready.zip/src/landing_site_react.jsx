import React from "react";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";

export default function Landing() {
  const [open, setOpen] = React.useState(false);
  const [activeFile, setActiveFile] = React.useState(null);
  const [adminMode, setAdminMode] = React.useState(false);
  const [editing, setEditing] = React.useState(false);
  const [flicker, setFlicker] = React.useState(false);
  const [dossiers, setDossiers] = React.useState(() => {
    // initial data, try load from localStorage
    try {
      const saved = typeof window !== 'undefined' && localStorage.getItem('dossiers_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse saved dossiers', e);
    }
    return [
      { id: 1, name: 'Кирилл', age: 29, disorder: 'Параноидальное расстройство', note: 'Под наблюдением' },
      { id: 2, name: 'Сергей', age: 34, disorder: 'Биполярное расстройство', note: 'Принимает лекарства' },
      { id: 3, name: 'Анастасия', age: 26, disorder: 'Шизофрения', note: 'Требует консультации' },
      { id: 4, name: 'Елена', age: 41, disorder: 'Депрессивное расстройство', note: 'Реабилитация' }
    ];
  });

  // save on changes
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('dossiers_v1', JSON.stringify(dossiers));
      } catch (e) {
        console.warn('Failed to save dossiers', e);
      }
    }
  }, [dossiers]);

  // background images (use your generated corridor images in /public)
  const backgrounds = ['/corridor1.jpg', '/corridor2.jpg'];
  const [bgIndex, setBgIndex] = React.useState(0);
  React.useEffect(() => {
    const t = setInterval(() => setBgIndex(i => (i + 1) % backgrounds.length), 8000);
    return () => clearInterval(t);
  }, []);

  // flicker effect randomly
  React.useEffect(() => {
    let running = true;
    async function loop() {
      while (running) {
        await new Promise(r => setTimeout(r, 3000 + Math.random() * 7000));
        setFlicker(true);
        await new Promise(r => setTimeout(r, 120 + Math.random() * 400));
        setFlicker(false);
      }
    }
    loop();
    return () => { running = false; };
  }, []);

  // audio refs
  const ambientRef = React.useRef(null);
  const cctvRef = React.useRef(null);
  const folderRef = React.useRef(null);
  const dripRef = React.useRef(null);

  React.useEffect(() => {
    // try to play audio when mounted (browsers may block autoplay without interaction)
    try {
      ambientRef.current?.play?.().catch(() => {});
    } catch (e) {}
    try {
      cctvRef.current?.play?.().catch(() => {});
    } catch (e) {}
  }, []);

  function openFile(id) {
    // play folder open sound
    try {
      if (folderRef.current) {
        folderRef.current.currentTime = 0;
        folderRef.current.play?.();
      }
    } catch (e) {}
    const found = dossiers.find(d => d.id === id);
    setActiveFile(found || null);
  }

  function saveActive(updated) {
    setDossiers(ds => ds.map(d => d.id === updated.id ? updated : d));
    setEditing(false);
    setActiveFile(updated);
  }

  function toggleAdmin() {
    // simple password prompt — change for production
    if (!adminMode) {
      const pass = prompt('Введите пароль администратора:');
      if (pass === 'admin') setAdminMode(true);
      else alert('Неверный пароль');
    } else {
      setAdminMode(false);
    }
  }

  return (
    <div className="min-h-screen w-full bg-black text-white font-sans relative overflow-hidden">
      {/* Background corridor */}
      <div className="fixed inset-0 z-0">
        <img
          src={backgrounds[bgIndex]}
          alt="Коридор"
          className={`w-full h-full object-cover transition-opacity duration-2000 ${flicker ? 'opacity-40' : 'opacity-70'}`}
        />
        {/* dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-black/60"></div>
      </div>

      {/* Audio elements (place files into public/) */}
      <audio ref={ambientRef} src="/doug-maxwell-heartbeat-of-the-hood.mp3" loop />
      <audio ref={cctvRef} src="/cctv-noise.mp3" loop />
      <audio ref={folderRef} src="/folder-open.mp3" />
      <audio ref={dripRef} src="/drip.mp3" />

      {/* flicker overlay */}
      <div className={`pointer-events-none fixed inset-0 z-40 ${flicker ? 'flicker-on' : ''}`}></div>

      {/* Navbar */}
      <header className="w-full fixed top-0 z-50 backdrop-blur bg-black/30 border-b border-white/5">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
          <h1 className="text-xl font-bold tracking-wide">ПсихБлок А-13</h1>

          <div className="flex items-center gap-4">
            <button onClick={toggleAdmin} className="text-sm bg-white/5 px-3 py-1 rounded hover:bg-white/10">{adminMode ? 'Выйти из админа' : 'Войти в админ'}</button>
            <button className="md:hidden p-2" onClick={() => setOpen(!open)}>
              {open ? <X /> : <Menu />}
            </button>
          </div>

          <nav className="hidden md:flex gap-8 text-sm opacity-90">
            <a href="#files" className="hover:text-red-400 transition">Личные дела</a>
          </nav>
        </div>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="md:hidden bg-black/80 border-t border-white/10">
            <div className="flex flex-col px-4 py-4 gap-3 text-sm">
              <a href="#files" className="hover:text-red-400 transition">Личные дела</a>
            </div>
          </motion.div>
        )}
      </header>

      {/* Hero: corridor title */}
      <section className="w-full h-screen flex flex-col justify-center items-center text-center px-4 relative z-10">
        <motion.h2 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="text-5xl md:text-6xl font-extrabold tracking-tight drop-shadow-xl">
          Психиатрический Корпус №13
        </motion.h2>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5, duration: 1 }} className="mt-4 text-lg md:text-xl opacity-80 max-w-2xl drop-shadow-lg">
          Доступ к личным делам пациентов закрытого учреждения.
        </motion.p>
      </section>

      {/* Files grid */}
      <section id="files" className="px-4 py-24 max-w-6xl mx-auto relative z-10">
        <h3 className="text-3xl font-bold mb-8 text-center">Личные дела</h3>
        <div className="grid md:grid-cols-4 gap-6">
          {dossiers.map((d) => (
            <motion.div key={d.id} whileHover={{ scale: 1.04 }} className="p-6 border border-white/10 rounded-xl bg-white/5 backdrop-blur shadow-xl cursor-pointer text-center" onClick={() => openFile(d.id)}>
              <div className="text-lg font-semibold">{d.name}</div>
              <div className="text-sm opacity-70 mt-2">Возраст: {d.age}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Active file modal */}
      {activeFile && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 bg-black/85 backdrop-blur z-50 flex items-center justify-center p-4">
          <motion.div initial={{ scale: 0.6, rotate: -8, opacity: 0 }} animate={{ scale: 1, rotate: 0, opacity: 1 }} transition={{ type: 'spring', stiffness: 120 }} className="bg-neutral-900 border border-white/20 rounded-2xl p-6 w-full max-w-2xl shadow-2xl relative">
            <button className="absolute top-3 right-3 text-sm opacity-60 hover:opacity-100" onClick={() => setActiveFile(null)}>Закрыть</button>

            <h2 className="text-2xl font-bold mb-4">Досье: {activeFile.name}</h2>

            {!editing && (
              <div className="grid gap-3 text-sm opacity-90">
                <p><b>Имя:</b> {activeFile.name}</p>
                <p><b>Возраст:</b> {activeFile.age}</p>
                <p><b>Психическое расстройство:</b> {activeFile.disorder}</p>
                <p><b>Примечание:</b> {activeFile.note}</p>
              </div>
            )}

            {adminMode && !editing && (
              <div className="mt-4 flex gap-2">
                <button className="bg-red-600 px-3 py-1 rounded" onClick={() => { setEditing(true); }}>Редактировать</button>
                <button className="bg-white/10 px-3 py-1 rounded" onClick={() => {
                  // play drip and toggle a little blood effect
                  dripRef.current?.play?.();
                  // quick visual: add a small red drop element
                  const drop = document.createElement('div');
                  drop.className = 'drip-temp';
                  document.body.appendChild(drop);
                  setTimeout(() => drop.remove(), 2000);
                }}>Симулировать кровь</button>
              </div>
            )}

            {editing && (
              <EditForm initial={activeFile} onCancel={() => setEditing(false)} onSave={(u) => saveActive(u)} />
            )}
          </motion.div>
        </motion.div>
      )}

      <footer className="text-center opacity-40 py-10 text-sm relative z-10">© 2025 Корпус №13</footer>

      {/* Small styles */}
      <style>{`
        .flicker-on::before {
          content: '';
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 20% 10%, rgba(255,255,255,0.02), transparent 20%), rgba(0,0,0,0.2);
          mix-blend-mode: multiply;
          animation: flicker 140ms steps(2) infinite;
        }
        @keyframes flicker {
          0% { opacity: 0.2 }
          50% { opacity: 0 }
          100% { opacity: 0.2 }
        }
        .drip-temp {
          position: fixed;
          right: 30px;
          top: 80px;
          width: 14px;
          height: 14px;
          background: rgba(180,0,0,0.95);
          border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
          box-shadow: 0 0 8px rgba(180,0,0,0.6);
          animation: drip 1.6s linear forwards;
          z-index: 80;
        }
        @keyframes drip {
          0% { transform: translateY(0) scale(0.6) }
          40% { transform: translateY(120px) scale(1) }
          100% { transform: translateY(220px) scale(1) opacity:0 }
        }
      `}</style>
    </div>
  );
}

function EditForm({ initial, onCancel, onSave }) {
  const [form, setForm] = React.useState({ ...initial });
  React.useEffect(() => setForm({ ...initial }), [initial]);

  return (
    <form className="mt-4 grid gap-3" onSubmit={(e) => { e.preventDefault(); onSave({ ...form, id: initial.id }); }}>
      <label className="text-sm">Имя
        <input className="w-full mt-1 bg-neutral-800 p-2 rounded" value={form.name || ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
      </label>
      <label className="text-sm">Возраст
        <input type="number" className="w-full mt-1 bg-neutral-800 p-2 rounded" value={form.age || ''} onChange={e => setForm(f => ({ ...f, age: e.target.value }))} />
      </label>
      <label className="text-sm">Психическое расстройство
        <input className="w-full mt-1 bg-neutral-800 p-2 rounded" value={form.disorder || ''} onChange={e => setForm(f => ({ ...f, disorder: e.target.value }))} />
      </label>
      <label className="text-sm">Примечание
        <textarea className="w-full mt-1 bg-neutral-800 p-2 rounded" value={form.note || ''} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} />
      </label>
      <div className="flex gap-2">
        <button type="submit" className="bg-green-600 px-3 py-1 rounded">Сохранить</button>
        <button type="button" className="bg-white/10 px-3 py-1 rounded" onClick={onCancel}>Отмена</button>
      </div>
    </form>
  );
}
